#include "HackEnrollment.h"
#include <ctype.h>

int cloneAndLower(const char* sourceFile, const char* destFile) {
    FILE *src_fp, *dest_fp;
    char c;
    
    // Open source file for reading
    src_fp = fopen(sourceFile, "r");
    if (src_fp == NULL) {
        printf("Error opening source file: %s\n", sourceFile);
        return 1;
    }
    
    // Open destination file for writing
    dest_fp = fopen(destFile, "w");
    if (dest_fp == NULL) {
        printf("Error opening destination file: %s\n", destFile);
        fclose(src_fp);
        return 1;
    }
    
    // Copy contents of source file to destination file, converting uppercase to lowercase
    while ((c = fgetc(src_fp)) != EOF) {
        fputc(tolower(c), dest_fp);
    }
    
    // Close files
    fclose(src_fp);
    fclose(dest_fp);
    
    return 0;
}

int main(int argc, char *argv[]) {
    int argCount = 0;
    const char* srcFile = "studentsFile.txt";
    const char* destFile = "students.txt";
    FILE* studentsFile;
    FILE* students;
    if(argc>6){
        argCount=1;
        studentsFile = fopen(argv[argCount+1], "w");
        cloneAndLower(srcFile, destFile);
    }else{
        students = fopen(argv[argCount+1],"r");
    }
    char *flag = argv[1];
    FILE* courses = fopen(argv[argCount+2] ,"r");
    FILE* hackers = fopen(argv[argCount+3] ,"r");
    FILE* queues = fopen(argv[argCount+4], "r");
    FILE* target = fopen(argv[argCount+5], "w");

    if (!students || !courses || !hackers || !queues || !target){
        printf("couldn't open files\n");
        return 1;
    }

    EnrollmentSystem sys = createEnrollment(students, courses, hackers);
    if (sys == NULL)
        return 2;

    sys = readEnrollment(sys, queues);
    if (sys == NULL)
        return 3;

    if (hackEnrollment(sys, target) != HACKENROLLMENT_SUCCESS){
        printf("hackEnrollment ERROR\n");
    }

    destroyEnrollment(sys);
    fclose(students);
    fclose(courses);
    fclose(hackers);
    fclose(queues);
    fclose(target);
  

	return 0;
}